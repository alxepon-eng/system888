import React, { useState } from 'react';
import { UserRole } from '../types';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { TEACHER_PASSWORD } from '../constants';
import { GraduationCap, School, Lock } from 'lucide-react';

interface LoginProps {
  onLogin: (role: UserRole) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState<'student' | 'teacher'>('student');
  const [teacherPass, setTeacherPass] = useState('');
  const [error, setError] = useState('');

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (teacherPass === TEACHER_PASSWORD) {
      onLogin(UserRole.TEACHER);
    } else {
      setError('รหัสผ่านอาจารย์ไม่ถูกต้อง');
    }
  };

  return (
    <div className="max-w-md mx-auto animate-fade-in">
      <div className="flex mb-6 neo-brutalism rounded-xl overflow-hidden bg-white">
        <button
          className={`flex-1 py-4 font-bold flex items-center justify-center gap-2 transition-all ${
            activeTab === 'student' ? 'bg-pink-500 text-white' : 'hover:bg-gray-50 text-gray-400'
          }`}
          onClick={() => { setActiveTab('student'); setError(''); }}
        >
          <GraduationCap size={20} /> นักเรียน
        </button>
        <button
          className={`flex-1 py-4 font-bold flex items-center justify-center gap-2 transition-all ${
            activeTab === 'teacher' ? 'bg-purple-600 text-white' : 'hover:bg-gray-50 text-gray-400'
          }`}
          onClick={() => { setActiveTab('teacher'); setError(''); }}
        >
          <School size={20} /> อาจารย์
        </button>
      </div>

      <div className="bg-white p-8 rounded-xl neo-brutalism min-h-[320px] flex flex-col justify-center">
        {activeTab === 'student' ? (
          <div className="text-center space-y-6">
            <div className="w-20 h-20 bg-pink-100 rounded-full mx-auto flex items-center justify-center neo-brutalism-sm">
                <GraduationCap size={40} className="text-pink-500" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">เข้าสู่ระบบนักเรียน</h2>
              <p className="text-gray-500 text-sm mt-2">คลิกเพื่อเริ่มส่งงานเข้า Google Sheet</p>
            </div>
            <Button onClick={() => onLogin(UserRole.STUDENT)} className="w-full text-lg py-4">
              เริ่มใช้งานระบบ
            </Button>
          </div>
        ) : (
          <form onSubmit={handleTeacherLogin} className="space-y-6">
             <div className="w-20 h-20 bg-purple-100 rounded-full mx-auto flex items-center justify-center neo-brutalism-sm">
                <Lock size={40} className="text-purple-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 text-center">อาจารย์เข้าสู่ระบบ</h2>
            <Input 
              type="password" 
              label="รหัสผ่านเข้าใช้งาน" 
              placeholder="กรุณากรอกรหัสผ่าน"
              value={teacherPass}
              onChange={(e) => setTeacherPass(e.target.value)}
              error={error}
              autoFocus
            />
            <Button type="submit" className="w-full text-lg py-4 bg-purple-600 hover:bg-purple-700">
              ยืนยันรหัสผ่าน
            </Button>
          </form>
        )}
      </div>
    </div>
  );
};